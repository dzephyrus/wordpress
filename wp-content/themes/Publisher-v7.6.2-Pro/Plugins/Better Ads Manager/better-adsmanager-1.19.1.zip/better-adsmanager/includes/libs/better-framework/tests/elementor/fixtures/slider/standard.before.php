<?php

return array(
	'speed' => array(
		'name' => 'Title',
		'id'   => 'speed',
		'type' => 'slider',
		'desc' => 'Set the speed of the ticker cycling, in second.',
		'std'  => 10,

		'min' => 5,
		'max' => 85
	),
);