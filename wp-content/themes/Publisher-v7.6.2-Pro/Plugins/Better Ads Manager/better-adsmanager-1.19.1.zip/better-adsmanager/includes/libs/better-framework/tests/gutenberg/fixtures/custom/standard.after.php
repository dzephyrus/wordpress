<?php

return array(

	array(
		'id'        => 'the-id',
		'component' => 'BF_Custom',
		'args'      => array(
			'id' => 'hr1',
		),
		'key'       => 'hr1',
	),
);
