<?php

// Silence is better