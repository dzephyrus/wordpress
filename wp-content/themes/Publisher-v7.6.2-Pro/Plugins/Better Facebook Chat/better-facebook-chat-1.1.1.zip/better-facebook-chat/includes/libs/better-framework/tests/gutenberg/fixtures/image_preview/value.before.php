<?php

return array(
	'typo_mg_1_img' => array(
		'id'    => 'typo_mg_1_img',
		'type'  => 'image_preview',
		'value' => 'path/to/img.png',
		'align' => 'left',
	),
);