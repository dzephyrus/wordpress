<?php

return array(

	array(

		'name'      => 'Switch Label',
		'id'        => 'switch',
		'type'      => 'switch',
		'on-label'  => 'Yes',
		'off-label' => 'No',
	)
);
