<?php

$fields['chat_enabled'] = array(
	'std' => 1,
);


$fields['facebook_page'] = array(
	'std' => '',
);

$fields['theme_color'] = array(
	'std' => '#3186f7',
);

$fields['position'] = array(
	'std' => 'right-bottom',
);

$fields['logged_out_greeting'] = array(
	'std' => 'Hi! How can we help you?',
);


$fields['logged_in_greeting'] = array(
	'std' => 'Hi! How can we help you?',
);

