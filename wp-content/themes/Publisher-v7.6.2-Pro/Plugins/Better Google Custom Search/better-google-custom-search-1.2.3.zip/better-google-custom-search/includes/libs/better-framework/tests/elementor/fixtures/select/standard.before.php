<?php

return array(
	array(
		'name'    => 'Field Title',
		'id'      => 'field-id',
		'type'    => 'select',
		'options' => array(

			'opt-1' => 'option 1',
			'opt-2' => 'option 2',
		),
	)
);
