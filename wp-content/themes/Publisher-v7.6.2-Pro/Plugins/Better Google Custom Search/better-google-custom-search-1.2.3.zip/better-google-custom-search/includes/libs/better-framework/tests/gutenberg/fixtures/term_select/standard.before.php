<?php

return array(
	'ts' => array(
		'name' => 'Newsticker Category Filter',
		'id'   => 'ts',
		'desc' => 'Filter Newsticker posts to specific categories',
		'type' => 'term_select',
	),
);
