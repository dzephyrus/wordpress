<script>
    function BS_GCSE_Callback() {

        var attrs = {
            gname: 'gsearch',
            div: '{{SEARCH-WRAPPER-CLASS}}',
            tag: 'search',
            enableAutoComplete: true,
            attributes: {linkTarget: ''}
        };

        if (document.readyState != 'complete') {
            return google.setOnLoadCallback(function(){
                google.search.cse.element.render(attrs);

                var element = google.search.cse.element.getElement('gsearch');
                element.execute('{{SEARCH-QUERY}}');

            }, true);
        }

        google.search.cse.element.render(attrs);

        var element = google.search.cse.element.getElement('gsearch');
        element.execute('{{SEARCH-QUERY}}');
    };

    window.__gcse = {
        parsetags: 'explicit',
        callback: BS_GCSE_Callback
    };

    (function () {
        var cx = '{{SEARCH-ENGINE-ID}}';
        var gcse = document.createElement('script');
        gcse.type = 'text/javascript';
        gcse.async = true;
        gcse.src = 'https://cse.google.com/cse.js?cx=' + cx;
        var s = document.getElementsByTagName('script')[0];
        s.parentNode.insertBefore(gcse, s);
    })();
</script>

<div id="{{SEARCH-WRAPPER-CLASS}}" class="{{SEARCH-WRAPPER-CLASS}} {{SEARCH-CLASS}}">
	<div id="bs-gcse-results-loading">{{SEARCH-LOADING}}</div>
</div>
