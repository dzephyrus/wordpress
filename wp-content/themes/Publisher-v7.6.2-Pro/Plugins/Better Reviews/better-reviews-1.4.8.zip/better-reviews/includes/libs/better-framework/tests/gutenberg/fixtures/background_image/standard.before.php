<?php

return array(
	'field1' => array(
		'name'         => 'Site Background Image',
		'id'           => 'field1',
		'type'         => 'background_image',
		'upload_label' => 'Upload Image',
		'desc'         => 'Use light patterns in non-boxed layout',
		'media_title'  => 'media-title',
		'button_text'  => 'button-text',
		'upload_label' => 'upload-label',
		'remove_label' => 'remove-label',
		'input_class'  => 'input-class'
	),
);