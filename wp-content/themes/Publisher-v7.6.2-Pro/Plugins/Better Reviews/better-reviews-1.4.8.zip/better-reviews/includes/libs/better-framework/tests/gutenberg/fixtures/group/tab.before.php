<?php

return array(
	array(
		'name' => 'Group title',
		'id'   => 'the_id',
		'type' => 'tab',
	),
	array(
		'name'  => 'Field Title',
		'id'    => 'text',
		'type'  => 'text',
		'style' => [],
	)
);
