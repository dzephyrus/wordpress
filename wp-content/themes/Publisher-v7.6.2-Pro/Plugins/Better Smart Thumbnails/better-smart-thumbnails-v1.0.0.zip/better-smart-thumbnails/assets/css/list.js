module.exports = [
    'assets/css/better-smart-thumbnails.css',
];
