module.exports = [

    'assets/js/utils.js',
    'assets/js/preview-data.js',
    'assets/js/preview-modal.js',
    'assets/js/focus-point.js',
    'assets/js/media-modal.js',
    'assets/js/media-lib-page.js',
];
