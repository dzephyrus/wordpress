<?php

$fields['enable'] = array(
	'std' => TRUE,
);

$fields['grid'] = array(
	'std' => FALSE,
);

$fields['force-clear-cache'] = array(
	'std' => FALSE,
);

$fields['default-focus-point'] = array(
	'std' => 'center-center',
);

$fields['portrait-default-top'] = array(
	'std' => FALSE,
);

$fields['enlarge-smaller'] = array(
	'std' => FALSE,
);

$fields['delete-unused-thumbnail'] = array(
	'std' => TRUE,
);