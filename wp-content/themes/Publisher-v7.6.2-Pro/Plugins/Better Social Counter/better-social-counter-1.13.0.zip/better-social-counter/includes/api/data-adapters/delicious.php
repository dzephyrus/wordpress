<?php

return array(

	'name'       => Better_Social_Counter::get_option( 'delicious_name' ),
	'title'      => Better_Social_Counter::get_option( 'delicious_title' ),
	'button'     => Better_Social_Counter::get_option( 'delicious_button' ),
	'id'         => Better_Social_Counter::get_option( 'delicious_username' ),
	'title_join' => Better_Social_Counter::get_option( 'delicious_title_join' ),
);
