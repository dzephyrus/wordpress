<?php

return array(

	'link'       => Better_Social_Counter::get_option( 'linkedin_link' ),
	'name'       => Better_Social_Counter::get_option( 'linkedin_name' ),
	'title'      => Better_Social_Counter::get_option( 'linkedin_title' ),
	'button'     => Better_Social_Counter::get_option( 'linkedin_button' ),
	'title_join' => Better_Social_Counter::get_option( 'linkedin_title_join' ),
);
