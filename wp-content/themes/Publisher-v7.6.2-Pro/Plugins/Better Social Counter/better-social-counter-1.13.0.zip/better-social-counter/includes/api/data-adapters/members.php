<?php

return array(

	'name'       => Better_Social_Counter::get_option( 'members_name' ),
	'title'      => Better_Social_Counter::get_option( 'members_title' ),
	'title_join' => Better_Social_Counter::get_option( 'members_title_join' ),
);
