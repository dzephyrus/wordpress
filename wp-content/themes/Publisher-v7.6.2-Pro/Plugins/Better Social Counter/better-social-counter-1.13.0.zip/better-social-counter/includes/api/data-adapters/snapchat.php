<?php

return array(

	'id'         => Better_Social_Counter::get_option( 'snapchat_link' ),
	'name'       => Better_Social_Counter::get_option( 'snapchat_name' ),
	'title'      => Better_Social_Counter::get_option( 'snapchat_title' ),
	'button'     => Better_Social_Counter::get_option( 'snapchat_button' ),
	'title_join' => Better_Social_Counter::get_option( 'snapchat_title_join' ),
);
