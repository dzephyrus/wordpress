<?php

return array(
	'typo' => array(
		'name'    => 'Slider 1 Heading',
		'id'      => 'typo',
		'type'    => 'typography',
		'preview' => true,
	),
);