<?php

return array(

	'switch-id' => array(

		'name'      => 'Switch Label',
		'id'        => 'switch-id',
		'type'      => 'switch',
		'on-label'  => 'Yes',
		'off-label' => 'No',
	)
);
