<?php

return array(

	array(

		'id'        => 'field_hd1',
		'component' => 'BF_Section_Container',
		'args'      => array(
			'type'  => 'bf-heading',
			'label' => '',
			'id'    => 'field_hd1',
			'name'  => 'hd1',
		),

		'key' => 'field_hd1',

		'children' => array(

			array(
				'id'        => 'hd1',
				'component' => 'BF_Heading',
				'args'      => array(
					'id'     => 'hd1',
					'title'  => 'Slider',
					'layout' => 'style-2',
				),
				'key'       => 'hd1',
			),
		),
	),
);
