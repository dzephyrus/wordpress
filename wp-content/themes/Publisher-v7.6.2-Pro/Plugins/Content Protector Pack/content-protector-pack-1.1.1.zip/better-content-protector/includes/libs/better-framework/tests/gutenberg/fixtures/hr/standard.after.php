<?php

return array(

	array(

		'id'        => 'field_hr1',
		'component' => 'BF_Section_Container',
		'args'      => array(
			'type'  => 'bf-hr',
			'label' => '',
			'id'    => 'field_hr1',
			'name'  => 'hr1',
		),

		'key' => 'field_hr1',

		'children' => array(

			array(
				'id'        => 'hr1',
				'component' => 'BF_Hr',
				'args'      => array(
					'id' => 'hr1',
				),
				'key'       => 'hr1',
			),
		),
	),
);
