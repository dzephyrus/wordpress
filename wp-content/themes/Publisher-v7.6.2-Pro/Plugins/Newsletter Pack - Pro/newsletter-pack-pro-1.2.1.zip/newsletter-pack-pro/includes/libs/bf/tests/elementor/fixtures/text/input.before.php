<?php

return array(
	'title' => array(
		'name' => 'Tab Title',
		'id'   => 'title',
		'type' => 'text',
	),
);
