<?php

return array(

	array(

		'id'        => 'field_field-id',
		'component' => 'BF_Section_Container',
		'args'      => array(
			'type'  => 'color-palette',
			'label' => 'Field Title',
			'id'    => 'field_field-id',
			'name'  => 'field-id',
		),

		'key' => 'field_field-id',

		'children' => array(

			array(

				'id'        => 'field-id',
				'component' => 'ColorPalette',
				'args'      => array(
					'id' => 'field-id',
				),

				'key'       => 'field-id',
				'attribute' => Array(
					'type'  => 'string',
					'items' => false,
				),
			),
		),
	),

);
