<?php

return array(
	'hr1' => array(
		'id'   => 'hr1',
		'type' => 'hr',
	),
);