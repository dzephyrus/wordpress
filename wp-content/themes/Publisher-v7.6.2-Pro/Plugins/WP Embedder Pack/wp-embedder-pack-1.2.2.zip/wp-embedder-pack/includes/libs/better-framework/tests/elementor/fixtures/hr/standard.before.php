<?php

return array(
	'hr1' => array(
		'id'   => 'hr1',
		'name' => 'hr',
		'type' => 'hr',
	),
);