<?php

return array(
	'head' => array(
		'name' => 'GTM',
		'id'   => 'head',
		'type' => 'textarea',
		'desc' => 'Enter GTM code that should be appear after head',
	),
);
