<div class="wep-container add-custom-url">
	<form method="post" class="wep-form">
		<label for="wep-custom-url" class="wep-form-field">
			<?php _e( 'Direct link to the document', 'wp-embedder-pack' ) ?>:
			<input type="text" name="url" id="wep-custom-url" value="" placeholder="http://...">
		</label>
	</form>
</div>
